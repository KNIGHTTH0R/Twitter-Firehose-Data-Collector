<?php

print $argv[1];
